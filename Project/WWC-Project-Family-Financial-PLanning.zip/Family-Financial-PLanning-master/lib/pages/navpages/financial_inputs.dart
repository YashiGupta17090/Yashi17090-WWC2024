import 'package:flutter/material.dart';
import 'package:flutter_custom_clippers/flutter_custom_clippers.dart';
import 'package:google_fonts/google_fonts.dart';

class FinancialInputs extends StatelessWidget {
  FinancialInputs({Key? key});

  List items = ["Income/Salary", "Debts/Loans", "Investment"];
  List subTitles = [
    "(Annual)",
    "Tell us about your Loans",
    "Tell us about the investments you make"
  ];
  @override
  Widget build(BuildContext context) {
    return Text("hi");
  }
}

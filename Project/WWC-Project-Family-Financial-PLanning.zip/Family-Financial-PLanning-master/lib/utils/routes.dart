class MyRoutes {
  static String loginPage = "/login";
  static String homePage = "/home";
  static String signUpPage = "/signUp";
  static String onBoarding = "/onBoarding";
  static String profile = "/profile";
  static String mainPage = "/mainpage";
}

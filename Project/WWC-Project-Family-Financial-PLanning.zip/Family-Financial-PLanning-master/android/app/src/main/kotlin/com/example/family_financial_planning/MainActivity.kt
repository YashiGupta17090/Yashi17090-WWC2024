package com.example.family_financial_planning

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
